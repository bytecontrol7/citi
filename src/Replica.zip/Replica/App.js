import React from 'react';
import "bootstrap/dist/css/bootstrap.css";
import Eco from './routes'
class App extends  React.Component{
    render(){
        return(
            <>
            <Eco />
            </>
        )
    }
}
export default App